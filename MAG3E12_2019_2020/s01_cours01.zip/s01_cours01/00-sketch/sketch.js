// ----------------------------------------------
// Démarrage du sketch
function setup() 
{
	createCanvas(640,480);
}

// ----------------------------------------------
// Dessin sur l'élément <canvas>
function draw() 
{
	background(240);
	drawText("Hello p5.js",0,height-30);
}

