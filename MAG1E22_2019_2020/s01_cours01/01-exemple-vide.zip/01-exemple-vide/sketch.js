// Démarrage du sketch
function setup() 
{
	// Création de l'élément canvas, taille 500 x 500 pixels
	createCanvas(500,500);
}

// Dessin sur l'élément <canvas>
function draw() 
{
}